# Architecture

See full pipeline description as previously outlined.