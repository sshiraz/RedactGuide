# Privacy & Security Posture

Zero-upload local compute design.