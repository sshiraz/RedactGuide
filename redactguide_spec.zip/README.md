# RedactGuide — Local-Only PWA for Automatic Document Redaction

**One-line**: A privacy-first Progressive Web App that automatically finds and redacts sensitive info entirely in the browser. No uploads. HIPAA-friendly by design.
