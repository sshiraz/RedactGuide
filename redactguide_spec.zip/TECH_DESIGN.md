# Technical Design — Detection & Redaction

See detailed algorithms and quality gates.