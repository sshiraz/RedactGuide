# Testing Strategy

Golden fixtures, OCR revalidation tests.